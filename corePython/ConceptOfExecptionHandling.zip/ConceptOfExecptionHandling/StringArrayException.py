list=['a','b','c']
try:
    print(list[4])
except Exception as e:
    print(e)