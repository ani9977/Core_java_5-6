# WITHOUT THREAD
def hello():
    for i in range(15):
        print("Hello", i)


def hi():
    for i in range(15):
        print("hi", i)


hello()
hi()
